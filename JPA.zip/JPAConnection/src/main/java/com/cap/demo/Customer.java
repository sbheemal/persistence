package com.cap.demo;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {

	@Id
	private String customerid;
	private String customername;
	private String accountno;
	public String getCustomerid() {
		return customerid;
	}
	
	
	public Customer(String customerid, String customername, String accountno) {
		super();
		this.customerid = customerid;
		this.customername = customername;
		this.accountno = accountno;
	}


	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	public String getAccountno() {
		return accountno;
	}
	public void setAccountno(String accountno) {
		this.accountno = accountno;
	}
	@Override
	public String toString() {
		return "Customer [customerid=" + customerid + ", customername=" + customername + ", accountno=" + accountno
				+ "]";
	}
	
	
	
}
