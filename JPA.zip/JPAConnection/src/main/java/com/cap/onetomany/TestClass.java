package com.cap.onetomany;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entityManager = emf.createEntityManager();
		
		EntityTransaction transaction =entityManager.getTransaction();
		
		transaction.begin();
		
		Company tcs = new Company("TCS Consultancy Services");
		Company capg = new Company("Capgemini Consultancy Services");		
		
		Employee employee = new Employee(1001,"Sri", tcs);
		Employee employee1 = new Employee(1002,"Ram", tcs);
		Employee employee2 = new Employee(1003,"Neeraj", capg);	
		Employee employee3 = new Employee(1004,"Manoj", capg);
		
		entityManager.persist(tcs);
		entityManager.persist(capg);
		entityManager.persist(employee);
		entityManager.persist(employee1);
		entityManager.persist(employee2);
		entityManager.persist(employee3);
		
		transaction.commit();
		entityManager.close();

	}

}
