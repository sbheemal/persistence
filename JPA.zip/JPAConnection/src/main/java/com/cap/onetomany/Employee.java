package com.cap.onetomany;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Employee {
	@Id
	private int emloyeeId;
	private String empName;
	
	@ManyToOne
	@JoinColumn(name="CompanyFk")
	private Company company;
	
		
	public Employee() {
		super();
	}

	public Employee(int emloyeeId, String empName, Company company) {
		super();
		this.emloyeeId = emloyeeId;
		this.empName = empName;
		this.company = company;
	}

	public int getEmloyeeId() {
		return emloyeeId;
	}

	public void setEmloyeeId(int emloyeeId) {
		this.emloyeeId = emloyeeId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public String toString() {
		return "Employee [emloyeeId=" + emloyeeId + ", empName=" + empName + ", company=" + company + "]";
	}
	
	
	
}
